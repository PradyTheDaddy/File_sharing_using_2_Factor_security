<html>
<head>
<style>
.aa{
	margin-top:200px;
	box-shadow:0px 0px 10px black;
	width:30%;
}
td{
	padding:20px;
}
</style>
</head>
<body>
<form action="" method="post">
<center>
<div class="aa">
<table border='0' cellspacing='10' cellpadding='10' align="center">
<tr>
<td>User Name</td>
<td><input type='text' name='uname' id='uname' required></td>
</tr>
<tr>
<td>Password</td>
<td><input type='password' name='pass' id='pass' required></td>
</tr>
<tr>
<td><input type='submit' value='login' name='log'></td>
</tr>
<tr>
<td colspan='2'><a href='register.php'>New User?Click Here</a></td>
</tr>

</table>
</div>
</html>